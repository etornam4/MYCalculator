var num1 = 100
var num2 = 19
var addin = (num1 + num2)
var subtractin = (num1 - num2)
var multiplyin = (num1 * num2)
var dividin = (num1 / num2)
// addition
print( addin )
// subtract
print( subtractin )
// multiply
print( multiplyin )
// divide
print( dividin )
